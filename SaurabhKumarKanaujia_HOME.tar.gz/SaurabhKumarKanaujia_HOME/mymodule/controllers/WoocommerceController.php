<?php

namespace App\Mymodule\Controllers;

use App\Core\Controllers\BaseController;
use App\MyModule\Models\Product;  // If working with Models
use Phalcon\Http\Response;

class WoocommerceController extends BaseController
{

    public function testAction()
    {

        $remoteResponse = $this->di->getObjectManager()->get("\App\Connector\Components\ApiClient")
            ->init("mymodulewebapi", true)
            ->call("getProducts", array(), array(), "GET");
        echo "<pre>";
        // // print_r($remoteResponse['data']);
        // $mongo = $this->di->getObjectManager()->create('\App\Core\Models\BaseMongo');
        // $collection = $mongo->getCollectionForTable('products');
        // // $counter = $mongo->getCounter('mongo');
        $obj = new Product;
        $container = $obj->getCollectionForTable(false);
        foreach ($remoteResponse['data'] as $key => $value) {
            $container->insertOne($value);
        }

        die('inserted');
    }
    public function variationsAction()
    {

        $remoteResponse = $this->di->getObjectManager()->get("\App\Connector\Components\ApiClient")
            ->init("mymodulewebapi", true)
            ->call("getVariations", array(), array(), "GET");
        echo "<pre>";
        print_r($remoteResponse);

        die;
    }
}
