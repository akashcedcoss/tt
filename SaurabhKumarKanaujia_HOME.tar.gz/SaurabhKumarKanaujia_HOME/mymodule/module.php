<?php
return [
  'name' => 'mymodule',
  'sort_order' => 3,
  'active' => 1,
  'version' => '0.0.1'
];