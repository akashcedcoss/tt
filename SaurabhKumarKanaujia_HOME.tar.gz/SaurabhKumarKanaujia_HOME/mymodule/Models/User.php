<?php

namespace App\Mymodule\Models;

use App\Core\Models\BaseMongo;

Class User extends BaseMongo
{
    protected $table = "user_details";
    protected $collectionName = "user_details";
}