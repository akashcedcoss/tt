<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Aliexpresshome
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright © 2018 CedCommerce. All rights reserved.
 * @license     EULA http://cedcommerce.com/license-agreement.txt
 */

namespace App\Mymodule\Models;

use App\Core\Models\SourceModel as BaseSourceModel;
// use App\Spotifyhome\Models\Product;
// use App\Spotifyhome\Components\Product\ProductSchema;

/**
 * Handles and initiates the SQS.
 *
 * @since 1.0.0
 */
class SourceModel extends BaseSourceModel {

    
    /**
     * Validate request and return to Dashboard
     *
     * @param array $RemotePostData array containing the remote post data.
     * @since 1.0.0
     * @return array
     */
    public function commenceHomeAuth( $RemotePostData ) {
    
        // echo "<pre>"; print_r($RemotePostData); die;
        $postData = array(
            'remote_shop_id' => (string) $RemotePostData['data']['data']['shop_id'],
            'marketplace'    => $RemotePostData['data']['data']['marketplace'],
            'name'           => $RemotePostData['data']['data']['token_data']['user_nick'] ?? 'SpotifyDev',
            // 'expire_time' =>  $RemotePostData['data']['data']['token_data']['expire_time']
        );

        $user_id      = (string) $RemotePostData['rawResponse']['state'];
        $unique_keys  = ['remote_shop_id' => $postData['remote_shop_id']];
        $user_details = $this->di->getObjectManager()->get('\App\Core\Models\User\Details');
        $postData     = array_merge( $postData, $unique_keys);
        $response     = $user_details->addShop($postData, $user_id, array_keys($unique_keys));

        return [
            'success'               => true,
            'redirect_to_dashboard' => true,
            'message'               => $this->di->getLocale()->_( 'Your Spotify Account connected' ),
            'marketplace'           => 'spotify',
        ];
    }
}