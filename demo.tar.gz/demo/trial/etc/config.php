<?php
return [
    // "spotify" => [
    //     "setup" => [
    //         "auth_url" => "https://accounts.spotify.com/authorize?",
    //         "client_id" => "e6bbd03108454b5fbec792fe30d22443",
    //         "client_secret" => "f090e0dde99c43848d2e0b1d4d8d87b3",
    //         "redirect_uri" => "http://remote.local.cedcommerce.com/apiconnect/request/auth?sAppId=7",
    //         "scopes" => "user-read-private user-read-email",
    //     ]
    // ],
    'connectors' => [
        'mymodulewebapi' => [
            'code' => 'Trial',
            'type' => 'real',
            'is_source' => 0,
            'is_target' => 1,
            'image' => '',
            'icon' => '',
            'title' => 'Trial',
            'installed' => [],
            'description' => 'Trial integration',
            'source_model' => '\App\Trial\Models\SourceModel'
        ]
    ],
    'services' => [
        'aliexpress' => [
            'handler' => 'App\Connector\Models\User\Service',
            'code' => 'aliexpress',
            'title' => 'Aliexpress',
            'type' => 'uploader',
            'charge_type' => 'prepaid',
            'marketplace' => 'Aliexpress',
            'image' => '',
        ]
    ]
];