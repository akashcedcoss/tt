<?php

namespace App\Trial\Models;

use App\Core\Models\BaseMongo;

Class User extends BaseMongo
{
    protected $table = "user_details";
    protected $collectionName = "user_details";
}