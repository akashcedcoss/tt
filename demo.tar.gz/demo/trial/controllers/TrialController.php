<?php

namespace App\Trial\Controllers;

use App\Connector\Models\Vendor;
use App\Core\Controllers\BaseController;
use App\Trial\Models\User;  // If working with Models
use Phalcon\Http\Response;
use GuzzleHttp\Client;



class TrialController extends BaseController
{
    public function createAction()
    {
        // die('asasa');
        // $client = new Client();
        $remoteResponse = $this->di->getObjectManager()->get("\App\Connector\Components\ApiClient")
            ->init("mytrialapi", true)
            ->call("getProducts", array(), array(), "GET");
        echo "<pre>";
        print_r($remoteResponse);
        die;
    }
    public function meAction()
    {
        // die('me');
        $client = new Client();
        $remoteResponse = $this->di->getObjectManager()->get("\App\Connector\Components\ApiClient")
            ->init("mytrialapi", true)
            ->call("getDataa", array(), array(), "GET");
        
        print_r($remoteResponse);
        die;
    }
    public function testshowAction()
    {
        die('success');
    }
    public function indexAction()
    {
        echo "Hello5";
    }
}
