<?php

namespace App\Mytrialapi\Controllers;

use App\Core\Controllers\BaseController;
use App\MyModule\Models\Product;  // If working with Models
use Phalcon\Http\Response;

class IndexController extends BaseController
{
    public function indexAction()
    {
        # code...
    }
}
