<?php

namespace App\Mytrialapi\Api;

use App\Core\Models\User\Details;

class Spotify extends \App\Apiconnect\Api\Base
{

    protected $_component = "Woocommerce";

    // public function get($params){


    //     $response = array("Hello" => "Spotify"); 
    //     return [
    //         'success' => true,
    //         'data'    => $response
    //     ];
    // }
    public function get($params)
    {

        

        $header = [
            'Authorization' => "Bearer BQC8-2LFKGpBvVyRhogwH2dA5I6i3MZYpGd27rSRsaJ1yED5_-C8pYuWwB0f4a7xkAMqbvMzIXvtvtbEdO-lbBWC4GS8qoBphfP2J54ZmNqJDq7oUcYbOcEWsutsEvAjgXbO9QW200kjcw1APwqV3Sd7ilXyWCQU4Ij4EQ"
        ];
        $data = $this->di->getObjectManager()->get('\App\Core\Components\Guzzle')->call("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1c2VyX2lkIjoiNjI2YmQ4MjM0Yjk1ZWE2OTY4MzJkNWE5Iiwicm9sZSI6ImFkbWluIiwiZXhwIjoxNjgzNDQwNjIyLCJpc3MiOiJodHRwczpcL1wvYXBwcy5jZWRjb21tZXJjZS5jb20iLCJ0b2tlbl9pZCI6IjYyNzYxMDZlM2ZhOTMyM2Q2MDA2YTI1MiJ9.M2wb53i-m228ZwPDTkdxRG1wvsy9hunli1GC1otWMABdoEHCnpmW6-dmwTWhV8HxQN13luRe6pIgvibMDVaIju_yyV-sTL-SZHHqHh1vcJpfc8gJCMvRCUs2f1LCJyknl-fpj3SmKwYsHg4LU-C-avvEJ3LGoPXxeCe8F0_kLuOr59bvXSCnT1kYsrUrXM1BsxN4tV5DNamneyFaWo-ax0r6-E2loM-DwxEjSX50UKG4jVK1NTRSD70Ft8s4_ATUGHCCYFOmkFWgyKE5RvYfXF1dzSbQLuAN7NtCQ4kGPgjWBk2Ny4OxO3gXJtwwxzvAjPnzMrhJilQlMPayHCiMHQ", "POST");
        return [
            'success' => true,
            'data'    => $data
        ];
    }
}
