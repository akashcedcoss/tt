<?php

namespace App\Mytrialapi\Api;

use App\Core\Models\User\Details;

class Trial extends \App\Apiconnect\Api\Base
{

    protected $_component = "Trial";

    public function get($params)
    {
        $key = "cs_1c9db44a060d7dab3efbbddf2d9201865ef8a17e";
        $user = "ck_79d3bf0c757ad56495c4dd91a6aa4412d627a91b";
        $url = "https://demo.makewebbetter.com/mwb-role-based-pricing-for-woocommerce/wp-json/wc/v3/products?consumer_key=" . $user . "&consumer_secret=" . $key . "&type=simple";
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $response = json_decode($response, true);
        return [
            'success' => true,
            'data'    => $response
        ];
    }
    public function me($params)
    {
        $url = "https://cedcoss-stores.myshopify.com/admin/api/2022-04/products.json";
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $response = json_decode($response, true);
        // die("access");
        
        return [
            'success' => true,
            'data'    => $response
        ];
    }
}
