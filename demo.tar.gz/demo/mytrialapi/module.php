<?php
return [
  'name' => 'mytrialapi',
  'sort_order' => 4,
  'active' => 1,
  'version' => '0.0.1'
];