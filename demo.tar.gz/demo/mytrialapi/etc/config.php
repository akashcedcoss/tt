<?php
return [
    'marketplace-modules' => [
        'mytrialapi' => 'Mytrialapi'
    ]
];