<?php


use Phalcon\Mvc\Controller;

class IndexController extends Controller
{
    public function indexAction()
    {
        // return '<h1>Hello World!</h1>';
    }
    public function createAction()
    {

        $connection = $this->mongo; 

        if ($this->request->isPost()) {
            $postData = $this->request->getPost();

            $student = new Student($connection);
            $student->__set('roll_no',$postData['roll_number']);
            $student->__set('name', $postData['name']);
            $student->__set('address', $postData['address']);
            
            $student->save();
        }
    }
    public function updateAction() {
        $connection = $this->mongo;

        if($this->request->isPost()) {
            // $student->load(10);
            $postData = $this->request->getPost();

            $student = new Student($connection);
            $student->__set('roll_no',$postData['roll_number']);
            $student->__set('name', $postData['name']);
            $student->__set('address', $postData['address']);
            $student->update();
        }
    }
}
