<?php
return [
    'marketplace-modules' => [
        'mymodulewebapi' => 'Mymodulewebapi'
    ]
];