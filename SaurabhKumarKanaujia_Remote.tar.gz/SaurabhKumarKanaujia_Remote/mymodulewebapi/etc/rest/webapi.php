<?php

return array(

    'restapi' => [
        "v1" => [
            "GET" => [
                "routes" => [
                    "getProduct" => [
                        "url" => "getProduct",
                        "method" => "get",
                        "resource" => "product/get",
                        "component" => "Product"
                    ],
                    "getTracks" => [
                        "url" => "getTracks",
                        "method" => "get",
                        "resource" => "spotify/get",
                        "component" => "Spotify"
                    ],
                    "getProducts" => [
                        "url" => "getProducts",
                        "method" => "get",
                        "resource" => "woocommerce/get",
                        "component" => "Woocommerce"
                    ],
                    "getVariations" => [
                        "url" => "getVariations",
                        "method" => "getVariations",
                        "resource" => "woocommerce/getVariations",
                        "component" => "Woocommerce"
                    ]
                ]
            ]
        ]
    ]

);

/*
- getProduct key is the endpoint which we call from Home
- component key is the controller name to be called
- method key is the action that will be called
- resource key is the <controller>/<action> which is being called
- url key is same as endpoint
*/