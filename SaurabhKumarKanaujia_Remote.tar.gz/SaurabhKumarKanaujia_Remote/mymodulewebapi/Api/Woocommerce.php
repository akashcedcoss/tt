<?php

namespace App\Mymodulewebapi\Api;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;

use App\Core\Models\User\Details;
use App\Mymodulewebapi\Components\Authenticate\Sellerauth;

class Woocommerce extends \App\Apiconnect\Api\Base
{

    protected $_component = "Woocommerce";


    public function get($params)
    {
        $url = "https://demo.makewebbetter.com/mwb-role-based-pricing-for-woocommerce/wp-json/wc/v3/products";
        $ch = curl_init();

        $username = 'ck_79d3bf0c757ad56495c4dd91a6aa4412d627a91b'; 
        $password = 'cs_1c9db44a060d7dab3efbbddf2d9201865ef8a17e';

        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
        $response = curl_exec($ch);
        curl_close($ch); 

        return [
            'success' => true,
            'data'    =>  json_decode($response, true)
        ];


    }
    public function getVariations($params)
    {
        $url = "https://demo.makewebbetter.com/mwb-role-based-pricing-for-woocommerce/wp-json/wc/v3/products/733/variations";
        $ch = curl_init();

        $username = 'ck_79d3bf0c757ad56495c4dd91a6aa4412d627a91b'; 
        $password = 'cs_1c9db44a060d7dab3efbbddf2d9201865ef8a17e';

        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
        $response = curl_exec($ch);
        curl_close($ch); 

        return [
            'success' => true,
            'data'    =>  json_decode($response, true)
        ];


    }
}
