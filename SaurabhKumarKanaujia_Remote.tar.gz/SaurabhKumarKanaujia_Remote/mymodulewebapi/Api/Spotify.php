<?php

namespace App\Mymodulewebapi\Api;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;

use App\Core\Models\User\Details;
use App\Mymodulewebapi\Components\Authenticate\Sellerauth;

class Spotify extends \App\Apiconnect\Api\Base
{

    protected $_component = "Spotify";

    // public function get($params){


    //     $response = array("Hello" => "Spotify"); 
    //     return [
    //         'success' => true,
    //         'data'    => $response
    //     ];
    // }
    // public function get($params){
    //     // $obj = new \App\Core\Models\User\Details();
    //     // $result = $obj->findShop($params['shop_id']);
    //     // $name=$params['name'];
    //     // $type=$params['type'];
    //     $name = 'tum';
    //     $type = 'tracks';
    //     // $abc = $this->di->getRegistry()->getCurrentShop();
    //     // $result = $this->di->getRegistry();
    //     // print_r($abc);
    //     // die;
    //     $header= [
    //         'Authorization' => "Bearer BQAtZc3AEVD-8qb4WlKHPCFm76z9AD0XJDYXushTr7TL-tTWdxJ7CsECb7C89ngi2AS1mRpf35mi_CcEpPrWYr2tpxGPfId4JxftpvbqckBkNa2hRCBTXVguv_lgjgsCxU2xBwW7XPpBga9VNrvHNST6baS85gQ2X4Zgug" 
    //     ];
    //     // $header = 'Bearer BQCgidXtpARmq-uSHnlNilqat0ikKnyl5STPicQggv7IQPNOOYRWi6UNvgtaMkaTEIbmaCP9x3l7i8jpcmx3cyt6x7qtqEXLEILFwfIPJbY6YxbkrWAcPgmvBIFQbJEu5rzUUuHBNKntjpo042FwHITl0kd-UW8BtL1axg';
    //     $data = $this->di->getObjectManager()->get('\App\Core\Components\Guzzle')->call("https://api.spotify.com/v1/search?type=album&q=tum", $header, "GET");
    //     return [
    //         'success' => true,
    //         'data'    => $data
    //     ];
    // }

    public function get($params)
    {
        $name = $params['postData']['search'];
        // $type = $params['type'];
        // $name = 'humdard';
        $type = 'track';

        $shopData = $this->di->getRegistry()->getCurrentShop();
        

        // $response = $this->di->getObjectManager()->get("\App\Core\Components\Guzzle")
        //     ->call("https://api.spotify.com/v1/search", ["Authorization" => "Bearer ".$shopData['token']['access_token'] ], "q=" . $name . "&type=" . $type . "&include_external=audio", "GET");

            try {
                $client = new Client();
                $result = $client->request('GET', "https://api.spotify.com/v1/search?q=$name&type=$type", [
                    'headers' => [
                        'Authorization' => "Bearer " . $shopData['token']['access_token']
                    ]
                ]);
                $res = json_decode($result->getBody()->getContents(),true);
                return [
                    'success' => true,
                    'data'    =>  $res
                ];
            } catch (ClientException $e) {
                $refreshToken = $shopData['token']['refresh_token'];
                $shopId = $shopData['id'];
                $obj = new Sellerauth();
                $obj->getRefreshToken($refreshToken, $shopId);
                return [
                    'success' => true,
                    'data'    =>  'reCall'
                ];
            }

    }
}
