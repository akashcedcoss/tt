<?php

namespace App\Mymodulewebapi\Api;

Class Product extends \App\Apiconnect\Api\Base
{

    protected $_component = "Product";

    public function get($params){
        
        $response = array("Hello" => "World"); 
        return [
            'success' => true,
            'data'    => $response
        ];
    }

}